﻿# Add and import AD PowerShell
Add-WindowsFeature RSAT-AD-PowerShell
Import-Module ActiveDirectory

# Host name of Windows Admin Center
$wac = "<WAC-Hostname>"

# Server names and Cluster names that you want to manage with Windows Admin Center in your domain
$servers = "AzureStack-N1", "AzureStack-N2", "AzureStack-Cluster", "AzureStack-DC1"

# Instead of adding manually the list of servers above
# You can specify the path of a .csv file to import a large number of servers/clusters
# If you want to provide a CSV file, please make sure to add a header to the column of computer names called 'NETBIOS_NAME'
#$servers = Read-Host "`nSpecify the full path to a CSV file (include spaces, but no quotes)" -ErrorAction Stop

Try {
    $CSVData = @(Import-CSV -Path $servers -ErrorAction Stop)
    Write-Verbose "Successfully imported entries from $servers"
    Write-Verbose "Total no. of servers in CSV are : $($CSVData.count)"
} 
Catch {
    Write-Verbose "Failed to read from the CSV file $servers Exiting!"
    Break
}

# Get the identity object of Windows Admin Center (WAC)
$wacobject = Get-ADComputer -Identity $wac

# Set the resource-based kerberos constrained delegation for each node
foreach ($server in $CSVData)
{
$server = $server.NETBIOS_NAME
$serverObject = Get-ADComputer -Identity $server
Set-ADComputer -Identity $serverObject -PrincipalsAllowedToDelegateToAccount $wacobject -verbose
}
# Clear KDC Cache
Invoke-Command -ComputerName $Servers -ScriptBlock {
    klist purge -li 0x3e7
}

